package com.kcrs.microservice.loyality.loYalityClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoYalityClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
