package com.kcrs.microservice.loyality.loYalityClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoYalityClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoYalityClientApplication.class, args);
	}

}
